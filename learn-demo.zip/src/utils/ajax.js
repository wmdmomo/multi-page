import axios from 'axios'
import Vue from 'vue'

Vue.prototype.$ajax = axios
export default Vue.prototype.$ajax